/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'ku', {
	title: 'بیرکاری لە TeX',
	button: 'بیرکاری',
	dialogInput: 'TeXەکەت لێرە بنووسە',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'بەڵگەنامەکردنی TeX',
	loading: 'بارکردن...',
	pathName: 'بیرکاری'
} );
